int is_num(char p1);
int check_for_parantheses_error(char* task);
int check_for_error(char* task);
int counting_equals(char* task);
int check_for_divide_error(char* task);
int check_for_char_error(char* task);
int check_for_one_number(char* task);
int check_for_minus(char* task, int index);